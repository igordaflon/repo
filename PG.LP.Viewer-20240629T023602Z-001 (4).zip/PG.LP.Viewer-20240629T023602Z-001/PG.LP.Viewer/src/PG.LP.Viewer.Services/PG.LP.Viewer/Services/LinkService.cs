﻿using Newtonsoft.Json.Linq;
using PG.LP.Model.LayoutBody;
using PG.LP.Processor.ApiModel.JobAsyncTaskCreation;
using PG.LP.Processor.Dto.Links;
using PG.LP.Processor.Repositories.Links;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace PG.LP.Viewer.Services;

public interface ILinkService
{
    Task<LinkInfoReponseDto?> GetInfoAsync(string code);
    Task<bool> ProcessPasswordAsync(string code, string password);
}

public class LinkService : ILinkService
{
    private readonly ILinkRepository linkRepository;

    public LinkService(ILinkRepository linkRepository)
    {
        this.linkRepository = linkRepository;
    }

    public async Task<LinkInfoReponseDto?> GetInfoAsync(string code)
    {
        var item = await linkRepository.GetAsync<LinkInfoDto>(code);
        if (item == null) return null;

        var linkInfo = new LinkInfoReponseDto { Code = code };

        var dataRecord = ExtractDataRecord(item.Contents);

        LoadFields(dataRecord, item.Job.Layout.LayoutVersion.Contents, linkInfo);

        return linkInfo;
    }

    public async Task<bool> ProcessPasswordAsync(string code, string password)
    {
        var item = await linkRepository.GetAsync<LinkInfoDto>(code);
        if (item == null) return false;

        var dataRecord = ExtractDataRecord(item.Contents);

        var request = JsonSerializer.Deserialize<JobAsyncTaskCreationRequest>(item.Job.Request);

        if(request is null || string.IsNullOrEmpty(request.WebPasswordField))
            return false;

        var linkPassword = MergeFields($"{{{request.WebPasswordField}}}", dataRecord);

        if(!linkPassword.Equals(password)) return false;

        return true;
    }

    private static JObject ExtractDataRecord(string dataRecord)
    {
        if (string.IsNullOrWhiteSpace(dataRecord))
        {
            return new JObject();
        }

        return JObject.Parse(dataRecord);
    }

    private static void LoadFields(JObject dataRecord, string contents, LinkInfoReponseDto linkInfo)
    {
        var layoutContents = JsonSerializer.Deserialize<LayoutContents>(contents);

        foreach (var page in layoutContents!.Pages)
        {
            foreach (var caption in page.Captions.Items)
            {
                string text = !string.IsNullOrEmpty(caption.Text) ? caption.Text : string.Empty;
                string text2 = MergeFields(text, dataRecord);
                if (text2 != text)
                {
                    caption.Text = text2;
                }
            }

            foreach (var action in page.Actions.Items)
            {
                string text = !string.IsNullOrEmpty(action.ActionParameter) ? action.ActionParameter : string.Empty;
                string text2 = MergeFields(text, dataRecord);
                if (text2 != text)
                {
                    action.ActionParameter = text2;
                }
            }

            foreach (var variable in page.Variables.Items)
            {
                string text = !string.IsNullOrEmpty(variable.Variable) ? variable.Variable : string.Empty;
                string text2 = MergeFields(text, dataRecord);
                if (text2 != text)
                {
                    variable.Variable = text2;
                }
            }
        }
        linkInfo.Contents = layoutContents;
    }

    private static string MergeFields(string value, JObject dataRecord)
    {
        if (string.IsNullOrEmpty(value))
        {
            return string.Empty;
        }

        string text = value;
        Match match = Regex.Match(value, "\\{([A-Za-z0-9_]+)(\\:[^\\}]+)?\\}");
        while (match.Success)
        {
            string value2 = match.Groups[0].Value;
            string value3 = match.Groups[1].Value;
            string value4 = match.Groups[2].Value;
            JToken value5 = dataRecord.GetValue(value3, StringComparison.CurrentCultureIgnoreCase)!;
            string newValue = ((!string.IsNullOrEmpty(value4)) ? string.Format("{0" + value4 + "}", value5) : (value5?.ToString() ?? string.Empty));
            text = text.Replace(value2, newValue);
            match = match.NextMatch();
        }

        return text;
    }
}
