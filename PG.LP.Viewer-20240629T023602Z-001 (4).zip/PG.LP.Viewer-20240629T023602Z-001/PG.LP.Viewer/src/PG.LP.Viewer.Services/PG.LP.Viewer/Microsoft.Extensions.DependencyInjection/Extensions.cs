﻿using Microsoft.Extensions.Configuration;
using PG.LP.Viewer.Services;

namespace Microsoft.Extensions.DependencyInjection;

public static class Extensions
{
    public static void AddViewerServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddProcessorRepositories(configuration);

        services.AddScoped<ILinkService, LinkService>();
    }
}
