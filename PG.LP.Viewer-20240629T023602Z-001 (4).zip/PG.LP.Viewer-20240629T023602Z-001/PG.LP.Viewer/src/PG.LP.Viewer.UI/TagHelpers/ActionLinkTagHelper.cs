﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using PG.LP.Model.LayoutBody;

namespace PG.LP.Viewer.UI.TagHelpers;

[HtmlTargetElement("action-link")]
public class ActionLinkTagHelper : TagHelper
{
    [HtmlAttributeName("action-item")]
    public ActionItem ActionItem { get; set; } = new();

    public override void Process(TagHelperContext context, TagHelperOutput output)
    {
        //<a class="action" href="actionParameter" style="background-color: backColor; color: foreColor">
        //    <div class="action-content">
        //        <div class="icon">
        //            <i class="fontAwesomeIcon"></i>
        //        </div>
        //        <span>Text</span>
        //    </div>
        //</a>

        output.TagName = "a";
        output.Attributes.Add("class", "action");
        output.TagMode = TagMode.StartTagAndEndTag;

        switch (ActionItem.ActionType)
        {
            case ActionType.Link:
                output.Attributes.Add("href", ActionItem.ActionParameter);
                output.Attributes.Add("target", "_blank");
                break;
            case ActionType.CopyText:
                output.Attributes.Add("onclick", $"copyToClipboard(this)");
                output.Attributes.Add("data-val", ActionItem.ActionParameter);
                output.Attributes.Add("data-text", ActionItem.Text);
                break;
            default:
                break;
        }

        output.Attributes.Add("style", $"background-color: {ActionItem.BackColor}; color: {ActionItem.ForeColor}");

        output.Content.AppendHtml($"<div class=\"action-content\"><div class=\"icon\"><i class=\"{ActionItem.Icon}\"></i></div><span>{ActionItem.Text}</span></div>");
    }
}
