﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace PG.LP.Viewer.UI.Pages;

public class CommonModel
{
    public Model.LayoutBody.Pages Page { get; set; } = new();
    public Model.LayoutBody.CaptionItems? Title { get; set; } = new();
    public Model.LayoutBody.CaptionItems? Prompt { get; set; } = new();
    public Model.LayoutBody.CaptionItems? ContactInfo { get; set; }

    [BindProperty]
    [Required(ErrorMessage = "O campo '{0}' é obrigatório")]
    [Display(Name = "Senha")]
    public string Password { get; set; } = string.Empty;

    public string? ErrorMessage { get; set; }
}
