﻿namespace PG.LP.Viewer.UI.Pages;

public static class Constants
{
    public const string UnexpectedError = "Desculpe, estamos tendo dificuldades técnicas em processar a sua requisição. Por favor tente mais tarde.";
    public const string MissingCode = "O link que você acessou não é válido, pois não contém um código.";
    public const string LinkNotFound = "Desculpe, o link não existe ou não está mais disponível.";
    public const string InvalidPasswordMessage = "Os dados informados não conferem. Por favor tente novamente.";
}
