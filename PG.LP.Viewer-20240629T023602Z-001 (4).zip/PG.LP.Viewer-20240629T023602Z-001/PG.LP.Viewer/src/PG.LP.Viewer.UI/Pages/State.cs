﻿namespace PG.LP.Viewer.UI.Pages;

public enum State
{
    Auth,
    LandingPage,
    Error
}
