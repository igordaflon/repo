﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PG.LP.Model.LayoutBody;
using PG.LP.Processor.Dto.Links;
using PG.LP.Viewer.Services;

namespace PG.LP.Viewer.UI.Pages;

public class IndexModel : PageModel
{
    private readonly ILinkService linkService;

    public IndexModel(ILinkService linkService)
    {
        this.linkService = linkService;
    }

    public LinkInfoReponseDto LinkInfo { get; set; } = default!;

    public State CurrentState { get; set; }

    public string Message { get; set; } = string.Empty;

    [BindProperty]
    public CommonModel Common { get; set; } = new();

    public async Task<IActionResult> OnGetAsync(string code)
    {
        if (string.IsNullOrEmpty(code))
            return GetPageResult(State.Error, Constants.MissingCode);

        try
        {
            if (!await LoadAsync(code))
                return GetPageResult(State.Error, Constants.LinkNotFound);

            if (!GetContentsPage(LinkInfo, LinkInfo.Contents!.Rule))
                return GetPageResult(State.Error, Constants.UnexpectedError);

            return Page();
        }
        catch
        {
            return GetPageResult(State.Error, Constants.UnexpectedError);
        }
    }

    private async Task<bool> LoadAsync(string code)
    {
        var linkInfo = await linkService.GetInfoAsync(code);

        if (linkInfo is null) return false;

        LinkInfo = linkInfo;

        return true;
    }

    private IActionResult GetPageResult(State state, string message)
    {
        CurrentState = state;
        Message = message;

        var page = Page();
        return page;
    }

    private bool GetContentsPage(LinkInfoReponseDto linkInfoReponse, LayoutRule rule)
    {
        if (linkInfoReponse.Contents is null || !linkInfoReponse.Contents.Pages.Any())
            return false;

        var cookie = Request.Cookies["LP.Session"];

        if (rule == LayoutRule.SinglePage || !string.IsNullOrEmpty(cookie))
        {
            CurrentState = State.LandingPage;
            Common.Page = linkInfoReponse.Contents.Pages.First(c => c.PageType == PageType.LandingPage);
        }
        else
        {
            CurrentState = State.Auth;
            Common.Page = linkInfoReponse.Contents.Pages.First(c => c.PageType == PageType.Auth);
        }

        Common.Title = Common.Page.Captions.Items.FirstOrDefault(c => c.Type == CaptionType.Title);
        Common.Prompt = Common.Page.Captions.Items.FirstOrDefault(c => c.Type == CaptionType.Prompt);
        Common.ContactInfo = Common.Page.Captions.Items.FirstOrDefault(c => c.Type == CaptionType.ContactInfo);

        return true;
    }

    public async Task<IActionResult> OnPostAsync(string code)
    {
        if (string.IsNullOrEmpty(code))
            return GetPageResult(State.Error, Constants.MissingCode);

        if (ModelState.IsValid)
        {
            if (!await linkService.ProcessPasswordAsync(code, Common.Password))
            {
                Common.ErrorMessage = Constants.InvalidPasswordMessage;

                if (!await LoadAsync(code))
                    return GetPageResult(State.Error, Constants.LinkNotFound);

                if (!GetContentsPage(LinkInfo, LinkInfo.Contents!.Rule))
                    return GetPageResult(State.Error, Constants.UnexpectedError);
                return Page();
            }

            if (!await LoadAsync(code))
                return GetPageResult(State.Error, Constants.LinkNotFound);

            if (!GetContentsPage(LinkInfo, LayoutRule.SinglePage))
                return GetPageResult(State.Error, Constants.UnexpectedError);

            Response.Cookies.Append(
                "LP.Session",
                code,
                new CookieOptions { Expires = DateTimeOffset.Now.AddMinutes(30), IsEssential = true });

            return Page();
        }

        if (!await LoadAsync(code))
            return GetPageResult(State.Error, Constants.LinkNotFound);

        if (!GetContentsPage(LinkInfo, LinkInfo.Contents!.Rule))
            return GetPageResult(State.Error, Constants.UnexpectedError);

        return Page();
    }
}